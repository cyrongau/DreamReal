<?php

namespace Botble\ACL\Repositories\Caches;

use Botble\ACL\Repositories\Eloquent\RoleRepository;

/**
 * @deprecated
 */
class RoleCacheDecorator extends RoleRepository
{
}
