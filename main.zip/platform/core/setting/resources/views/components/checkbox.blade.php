<x-core::form.checkbox {{ $attributes }} />
