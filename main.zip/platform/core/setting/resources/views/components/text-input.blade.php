<x-core::form.text-input {{ $attributes }} />
